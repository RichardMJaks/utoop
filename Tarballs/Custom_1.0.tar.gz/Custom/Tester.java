package Custom;

public class Tester {
    public static void main(String[] args) {
        System.out.println(OOPFunctions.rollDice("1d4"));
        System.out.println(OOPFunctions.rollDice("26d20"));
    }
}

class ParentClass {
    protected int a = 2;

    public int getA() {
        return this.a;
    }
}

class ChildClass extends ParentClass {
    public ChildClass() {
        this.a = 3;
    }
}
