package Kodutöö3;

public interface SelfEffect extends Effect {
}
